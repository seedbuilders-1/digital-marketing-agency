import React from "react";

const page = () => {
  return <div>Sadiq</div>;
};

export default page;
